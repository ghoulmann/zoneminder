window.addEvent( 'domready', function() { $('loginForm').elements['username'].focus() } );
