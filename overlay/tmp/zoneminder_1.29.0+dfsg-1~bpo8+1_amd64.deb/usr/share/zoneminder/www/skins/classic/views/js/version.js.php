var openZmWindow = <?php echo (isset($_REQUEST['action']) && $_REQUEST['action'] == "version" && $_REQUEST['option'] == "go")?'true':'false' ?>;
