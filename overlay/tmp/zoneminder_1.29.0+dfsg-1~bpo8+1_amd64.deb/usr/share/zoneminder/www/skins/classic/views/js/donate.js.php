var action = '<?php echo isset($_REQUEST['action'])?validJsStr($_REQUEST['action']):'' ?>';
var option = '<?php echo isset($_REQUEST['option'])?validJsStr($_REQUEST['option']):'' ?>';
