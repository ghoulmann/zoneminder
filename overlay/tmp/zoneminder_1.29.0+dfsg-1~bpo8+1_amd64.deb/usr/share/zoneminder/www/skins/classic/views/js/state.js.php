var running = <?php echo $running?'true':'false' ?>;
var applying = <?php echo !empty($_REQUEST['apply'])?'true':'false' ?>;
