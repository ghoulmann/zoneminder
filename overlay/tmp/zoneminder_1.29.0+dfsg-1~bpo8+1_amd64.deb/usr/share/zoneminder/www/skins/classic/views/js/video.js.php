var eventId = '<?php echo $event['Id'] ?>';

var videoGenSuccessString = '<?php echo addslashes(translate('VideoGenSucceeded')) ?>';
var videoGenFailedString = '<?php echo addslashes(translate('VideoGenFailed')) ?>';
var videoGenProgressString = '<?php echo addslashes(translate('GeneratingVideo')) ?>';
